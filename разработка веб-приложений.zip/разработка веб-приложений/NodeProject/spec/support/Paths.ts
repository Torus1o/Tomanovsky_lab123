/**
 * Convert paths to full for testing.
 */

import jetPaths from 'jet-paths';

import Paths from '@src/common/Paths';


export default jetPaths(Paths);
